# Tdmenu
A Joomla 5.x Three dimensional menu module responsive extension.
Put the joomla menu module in the same position(or some other positions but in the same page) as the tdmenu module menu
to be able to use the tdmenu, rest assured the joomla menu won't be appeared in the webpage
BUT it must be published exactly in the same page(s) as the tdmenu!
In the pro-version there are more features
For instance, in this version you only could make the first level of menu vertical or horizontal
and  all other levels are just vertical
but in the pro-version you will have the choice to select which level be vertical or horizontal
Also the feature to make menu module starts at which level and ends at which level is a feature of the pro-version,
for this version you have to create separate joomla menu module for each level instance and  assign it
to tdmenu, yet it still works.
It works without enabling the plugin backward compatibility of the behavior group, yet
it had better always enable this plugin just in case.
The software is designed by KWProductions Co. 
Email: webarchitect@kwproductions121.ir
In case of any problem.
Long live Science and Human mind to enslave artificial intelligence!